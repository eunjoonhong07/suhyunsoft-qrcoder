namespace QRCoder;

public static partial class PayloadGenerator
{
    /// <summary>
    /// Generates a ShadowSocks proxy config payload.
    /// </summary>
    public class ShadowSocksConfig : Payload
    {
        private readonly string _hostname, _password, _methodStr;
        private readonly string? _tag, _parameter;
        private readonly Method _method;
        private readonly int _port;
        private readonly Dictionary<string, string> _encryptionTexts = new Dictionary<string, string>() {
            { "Chacha20IetfPoly1305", "chacha20-ietf-poly1305" },
            { "Aes128Gcm", "aes-128-gcm" },
            { "Aes192Gcm", "aes-192-gcm" },
            { "Aes256Gcm", "aes-256-gcm" },

            { "XChacha20IetfPoly1305", "xchacha20-ietf-poly1305" },

            { "Aes128Cfb", "aes-128-cfb" },
            { "Aes192Cfb", "aes-192-cfb" },
            { "Aes256Cfb", "aes-256-cfb" },
            { "Aes128Ctr", "aes-128-ctr" },
            { "Aes192Ctr", "aes-192-ctr" },
            { "Aes256Ctr", "aes-256-ctr" },
            { "Camellia128Cfb", "camellia-128-cfb" },
            { "Camellia192Cfb", "camellia-192-cfb" },
            { "Camellia256Cfb", "camellia-256-cfb" },
            { "Chacha20Ietf", "chacha20-ietf" },

            { "Aes256Cb", "aes-256-cfb" },

            { "Aes128Ofb", "aes-128-ofb" },
            { "Aes192Ofb", "aes-192-ofb" },
            { "Aes256Ofb", "aes-256-ofb" },
            { "Aes128Cfb1", "aes-128-cfb1" },
            { "Aes192Cfb1", "aes-192-cfb1" },
            { "Aes256Cfb1", "aes-256-cfb1" },
            { "Aes128Cfb8", "aes-128-cfb8" },
            { "Aes192Cfb8", "aes-192-cfb8" },
            { "Aes256Cfb8", "aes-256-cfb8" },

            { "Chacha20", "chacha20" },
            { "BfCfb", "bf-cfb" },
            { "Rc4Md5", "rc4-md5" },
            { "Salsa20", "salsa20" },

            { "DesCfb", "des-cfb" },
            { "IdeaCfb", "idea-cfb" },
            { "Rc2Cfb", "rc2-cfb" },
            { "Cast5Cfb", "cast5-cfb" },
            { "Salsa20Ctr", "salsa20-ctr" },
            { "Rc4", "rc4" },
            { "SeedCfb", "seed-cfb" },
            { "Table", "table" }
        };

        /// <summary>
        /// Generates a ShadowSocks proxy config payload.
        /// </summary>
        /// <param name="hostname">Hostname of the ShadowSocks proxy</param>
        /// <param name="port">Port of the ShadowSocks proxy</param>
        /// <param name="password">Password of the SS proxy</param>
        /// <param name="method">Encryption type</param>
        /// <param name="tag">Optional tag line</param>
        public ShadowSocksConfig(string hostname, int port, string password, Method method, string? tag = null) :
            this(hostname, port, password, method, null, tag)
        { }

        /// <summary>
        /// Generates a ShadowSocks proxy config payload with plugin options.
        /// </summary>
        /// <param name="hostname">Hostname of the ShadowSocks proxy</param>
        /// <param name="port">Port of the ShadowSocks proxy</param>
        /// <param name="password">Password of the SS proxy</param>
        /// <param name="method">Encryption type</param>
        /// <param name="plugin">Plugin name</param>
        /// <param name="pluginOption">Plugin option</param>
        /// <param name="tag">Optional tag line</param>
        public ShadowSocksConfig(string hostname, int port, string password, Method method, string plugin, string? pluginOption, string? tag = null) :
            this(hostname, port, password, method, new Dictionary<string, string>
            {
                ["plugin"] = plugin + (
                string.IsNullOrEmpty(pluginOption)
                ? ""
                : $";{pluginOption}"
            )
            }, tag)
        { }
        private readonly Dictionary<string, string> _urlEncodeTable = new Dictionary<string, string>
        {
            [" "] = "+",
            ["\0"] = "%00",
            ["\t"] = "%09",
            ["\n"] = "%0a",
            ["\r"] = "%0d",
            ["\""] = "%22",
            ["#"] = "%23",
            ["$"] = "%24",
            ["%"] = "%25",
            ["&"] = "%26",
            ["'"] = "%27",
            ["+"] = "%2b",
            [","] = "%2c",
            ["/"] = "%2f",
            [":"] = "%3a",
            [";"] = "%3b",
            ["<"] = "%3c",
            ["="] = "%3d",
            [">"] = "%3e",
            ["?"] = "%3f",
            ["@"] = "%40",
            ["["] = "%5b",
            ["\\"] = "%5c",
            ["]"] = "%5d",
            ["^"] = "%5e",
            ["`"] = "%60",
            ["{"] = "%7b",
            ["|"] = "%7c",
            ["}"] = "%7d",
            ["~"] = "%7e",
        };

        private string UrlEncode(string i)
        {
            string j = i;
            foreach (var kv in _urlEncodeTable)
            {
                j = j.Replace(kv.Key, kv.Value);
            }
            return j;
        }

        /// <summary>
        /// Generates a ShadowSocks proxy config payload with additional parameters.
        /// </summary>
        /// <param name="hostname">Hostname of the ShadowSocks proxy</param>
        /// <param name="port">Port of the ShadowSocks proxy</param>
        /// <param name="password">Password of the SS proxy</param>
        /// <param name="method">Encryption type</param>
        /// <param name="parameters">Additional parameters</param>
        /// <param name="tag">Optional tag line</param>
        public ShadowSocksConfig(string hostname, int port, string password, Method method, Dictionary<string, string>? parameters, string? tag = null)
        {
            _hostname = Uri.CheckHostName(hostname) == UriHostNameType.IPv6
                ? $"[{hostname}]"
                : hostname;
            if (port < 1 || port > 65535)
                throw new ShadowSocksConfigException("Value of 'port' must be within 0 and 65535.");
            _port = port;
            _password = password;
            _method = method;
            _methodStr = _encryptionTexts[method.ToString()];
            _tag = tag;

            if (parameters != null)
                _parameter =
                    string.Join("&",
                    parameters.Select(
                        kv => $"{UrlEncode(kv.Key)}={UrlEncode(kv.Value)}"
                    ).ToArray());
        }

        /// <summary>
        /// Converts the ShadowSocks config payload to a string.
        /// </summary>
        /// <returns>A string representation of the ShadowSocks config payload.</returns>
        public override string ToString()
        {
            if (string.IsNullOrEmpty(_parameter))
            {
                var connectionString = $"{_methodStr}:{_password}@{_hostname}:{_port}";
                var connectionStringEncoded = Convert.ToBase64String(Encoding.UTF8.GetBytes(connectionString));
                return $"ss://{connectionStringEncoded}{(!string.IsNullOrEmpty(_tag) ? $"#{_tag}" : string.Empty)}";
            }
            var authString = $"{_methodStr}:{_password}";
            var authStringEncoded = Convert.ToBase64String(Encoding.UTF8.GetBytes(authString))
                .Replace('+', '-')
                .Replace('/', '_')
                .TrimEnd('=');
            return $"ss://{authStringEncoded}@{_hostname}:{_port}/?{_parameter}{(!string.IsNullOrEmpty(_tag) ? $"#{_tag}" : string.Empty)}";
        }

        /// <summary>
        /// Specifies the encryption methods used by ShadowSocks.
        /// </summary>
        public enum Method
        {
            // AEAD
            /// <summary>
            /// ChaCha20-IETF with Poly1305 AEAD encryption method
            /// </summary>
            Chacha20IetfPoly1305,

            /// <summary>
            /// AES-128 Galois/Counter Mode (GCM) encryption method
            /// </summary>
            Aes128Gcm,

            /// <summary>
            /// AES-192 Galois/Counter Mode (GCM) encryption method
            /// </summary>
            Aes192Gcm,

            /// <summary>
            /// AES-256 Galois/Counter Mode (GCM) encryption method
            /// </summary>
            Aes256Gcm,

            // AEAD, not standard
            /// <summary>
            /// Extended ChaCha20-IETF with Poly1305 AEAD encryption method (non-standard)
            /// </summary>
            XChacha20IetfPoly1305,

            // Stream cipher
            /// <summary>
            /// AES-128 Cipher Feedback (CFB) stream cipher
            /// </summary>
            Aes128Cfb,

            /// <summary>
            /// AES-192 Cipher Feedback (CFB) stream cipher
            /// </summary>
            Aes192Cfb,

            /// <summary>
            /// AES-256 Cipher Feedback (CFB) stream cipher
            /// </summary>
            Aes256Cfb,

            /// <summary>
            /// AES-128 Counter (CTR) stream cipher
            /// </summary>
            Aes128Ctr,

            /// <summary>
            /// AES-192 Counter (CTR) stream cipher
            /// </summary>
            Aes192Ctr,

            /// <summary>
            /// AES-256 Counter (CTR) stream cipher
            /// </summary>
            Aes256Ctr,

            /// <summary>
            /// Camellia-128 Cipher Feedback (CFB) stream cipher
            /// </summary>
            Camellia128Cfb,

            /// <summary>
            /// Camellia-192 Cipher Feedback (CFB) stream cipher
            /// </summary>
            Camellia192Cfb,

            /// <summary>
            /// Camellia-256 Cipher Feedback (CFB) stream cipher
            /// </summary>
            Camellia256Cfb,

            /// <summary>
            /// ChaCha20-IETF stream cipher
            /// </summary>
            Chacha20Ietf,

            // alias of Aes256Cfb
            /// <summary>
            /// Alias for AES-256 Cipher Feedback (CFB) stream cipher
            /// </summary>
            Aes256Cb,

            // Stream cipher, not standard
            /// <summary>
            /// AES-128 Output Feedback (OFB) stream cipher (non-standard)
            /// </summary>
            Aes128Ofb,

            /// <summary>
            /// AES-192 Output Feedback (OFB) stream cipher (non-standard)
            /// </summary>
            Aes192Ofb,

            /// <summary>
            /// AES-256 Output Feedback (OFB) stream cipher (non-standard)
            /// </summary>
            Aes256Ofb,

            /// <summary>
            /// AES-128 Cipher Feedback 1-bit (CFB1) stream cipher
            /// </summary>
            Aes128Cfb1,

            /// <summary>
            /// AES-192 Cipher Feedback 1-bit (CFB1) stream cipher
            /// </summary>
            Aes192Cfb1,

            /// <summary>
            /// AES-256 Cipher Feedback 1-bit (CFB1) stream cipher
            /// </summary>
            Aes256Cfb1,

            /// <summary>
            /// AES-128 Cipher Feedback 8-bit (CFB8) stream cipher
            /// </summary>
            Aes128Cfb8,

            /// <summary>
            /// AES-192 Cipher Feedback 8-bit (CFB8) stream cipher
            /// </summary>
            Aes192Cfb8,

            /// <summary>
            /// AES-256 Cipher Feedback 8-bit (CFB8) stream cipher
            /// </summary>
            Aes256Cfb8,

            // Stream cipher, deprecated
            /// <summary>
            /// ChaCha20 stream cipher (deprecated)
            /// </summary>
            Chacha20,

            /// <summary>
            /// Blowfish Cipher Feedback (CFB) stream cipher (deprecated)
            /// </summary>
            BfCfb,

            /// <summary>
            /// RC4-MD5 stream cipher (deprecated)
            /// </summary>
            Rc4Md5,

            /// <summary>
            /// Salsa20 stream cipher (deprecated)
            /// </summary>
            Salsa20,

            // Not standard and not in active use
            /// <summary>
            /// DES Cipher Feedback (CFB) stream cipher (not standard, not in active use)
            /// </summary>
            DesCfb,

            /// <summary>
            /// IDEA Cipher Feedback (CFB) stream cipher (not standard, not in active use)
            /// </summary>
            IdeaCfb,

            /// <summary>
            /// RC2 Cipher Feedback (CFB) stream cipher (not standard, not in active use)
            /// </summary>
            Rc2Cfb,

            /// <summary>
            /// CAST5 Cipher Feedback (CFB) stream cipher (not standard, not in active use)
            /// </summary>
            Cast5Cfb,

            /// <summary>
            /// Salsa20 Counter (CTR) stream cipher (not standard, not in active use)
            /// </summary>
            Salsa20Ctr,

            /// <summary>
            /// RC4 stream cipher (not standard, not in active use)
            /// </summary>
            Rc4,

            /// <summary>
            /// SEED Cipher Feedback (CFB) stream cipher (not standard, not in active use)
            /// </summary>
            SeedCfb,

            /// <summary>
            /// Table-based encryption method (not standard, not in active use)
            /// </summary>
            Table
        }

        /// <summary>
        /// Represents errors that occur during the generation of a ShadowSocksConfig payload.
        /// </summary>
        public class ShadowSocksConfigException : Exception
        {
            /// <summary>
            /// Initializes a new instance of the <see cref="ShadowSocksConfigException"/> class.
            /// </summary>
            public ShadowSocksConfigException()
            {
            }

            /// <summary>
            /// Initializes a new instance of the <see cref="ShadowSocksConfigException"/> class with a specified error message.
            /// </summary>
            /// <param name="message">The message that describes the error.</param>
            public ShadowSocksConfigException(string message)
                : base(message)
            {
            }

            /// <summary>
            /// Initializes a new instance of the <see cref="ShadowSocksConfigException"/> class with a specified error message and a reference to the inner exception that is the cause of this exception.
            /// </summary>
            /// <param name="message">The message that describes the error.</param>
            /// <param name="inner">The exception that is the cause of the current exception.</param>
            public ShadowSocksConfigException(string message, Exception inner)
                : base(message, inner)
            {
            }
        }
    }
}
